---
title: Organic Cotton T-Shirt
description: Ultra-soft premium t-shirt made from 100% certified organic cotton.
  Sustainably sourced and ethically manufactured for the conscious consumer.
price: 34.99
inStock: true
sku: CLO-OCT-003
category: Clothing
image: /assets/images/products/organic-cotton-tshirt.png
imageAlt: Navy blue organic cotton t-shirt
options:
  - name: Size
    required: true
    values:
      - name: Small
      - name: Medium
      - name: Large
      - name: X-Large
        price: "2"
specs:
  - name: Material
    value: 100% Organic Cotton
  - name: Weight
    value: 180 GSM
  - name: Fit
    value: Regular
  - name: Care
    value: Machine wash cold, tumble dry low
---

Our Organic Cotton T-Shirt combines supreme comfort with environmental responsibility. Made from GOTS-certified organic cotton, this everyday essential is soft on your skin and gentle on the planet.
