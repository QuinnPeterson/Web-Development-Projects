// ─────────────────────────────────────────────────────────────────────────────
// STORE PAGE FILTER & PAGINATION
// Client-side filtering and pagination for product listings
// Mobile: slide-in filter panel from left (like mobile nav)
// Desktop: always-visible sidebar
// ─────────────────────────────────────────────────────────────────────────────

(() => {
    // Configuration
    const CONFIG = {
        ITEMS_PER_PAGE: 9,
        BREAKPOINTS: {
            MOBILE: 1023.5,
        },
        SELECTORS: {
            body: 'body',
            filterToggle: '#cs-filter-toggle',
            filterSidebar: '#cs-filter-sidebar',
            filterClose: '#cs-filter-close',
            productGrid: '.cs-card-group',
            productItem: '.cs-item',
            categoryCheckbox: '.cs-category-checkbox',
            priceRadio: '.cs-price-radio',
            sortSelect: '#cs-sort-select',
            inStockToggle: '#cs-in-stock-toggle',
            onSaleToggle: '#cs-on-sale-toggle',
            clearFilters: '#cs-clear-filters',
            pagination: '#cs-pagination',
            pageButton: '.cs-page-btn',
            prevButton: '#cs-prev-page',
            nextButton: '#cs-next-page',
            resultsCount: '#cs-results-count',
            activeFiltersCount: '#cs-active-filters-count',
        },
        CLASSES: {
            active: 'cs-active',
            filterOpen: 'cs-filter-open',
            hidden: 'cs-hidden',
            disabled: 'cs-disabled',
        },
    };

    // State
    let state = {
        currentPage: 1,
        selectedCategories: [],
        selectedPriceRange: null,
        sortBy: 'newest',
        inStockOnly: false,
        onSaleOnly: false,
        allProducts: [],
        filteredProducts: [],
    };

    // DOM Elements
    const elements = {
        body: document.querySelector(CONFIG.SELECTORS.body),
        filterToggle: document.querySelector(CONFIG.SELECTORS.filterToggle),
        filterSidebar: document.querySelector(CONFIG.SELECTORS.filterSidebar),
        filterClose: document.querySelector(CONFIG.SELECTORS.filterClose),
        productGrid: document.querySelector(CONFIG.SELECTORS.productGrid),
        pagination: document.querySelector(CONFIG.SELECTORS.pagination),
        resultsCount: document.querySelector(CONFIG.SELECTORS.resultsCount),
        activeFiltersCount: document.querySelector(CONFIG.SELECTORS.activeFiltersCount),
        clearFilters: document.querySelector(CONFIG.SELECTORS.clearFilters),
        prevButton: document.querySelector(CONFIG.SELECTORS.prevButton),
        nextButton: document.querySelector(CONFIG.SELECTORS.nextButton),
        sortSelect: document.querySelector(CONFIG.SELECTORS.sortSelect),
        inStockToggle: document.querySelector(CONFIG.SELECTORS.inStockToggle),
        onSaleToggle: document.querySelector(CONFIG.SELECTORS.onSaleToggle),
    };

    // Utilities
    const isMobile = () => window.matchMedia(`(max-width: ${CONFIG.BREAKPOINTS.MOBILE}px)`).matches;

    // Scroll lock for mobile filter
    let scrollPosition = 0;

    function lockScroll() {
        // scrollPosition = window.pageYOffset;
        // document.documentElement.style.overflow = 'hidden';
        // document.body.style.overflow = 'hidden';
        // document.body.style.position = 'fixed';
        // document.body.style.top = `-${scrollPosition}px`;
        // document.body.style.width = '100%';
    }

    function unlockScroll() {
        // document.documentElement.style.overflow = '';
        // document.body.style.overflow = '';
        // document.body.style.position = '';
        // document.body.style.top = '';
        // document.body.style.width = '';
        // window.scrollTo(0, scrollPosition);
    }

    // Filter Sidebar Management
    const filterManager = {
        open() {
            if (!elements.filterSidebar) return;
            elements.filterSidebar.classList.add(CONFIG.CLASSES.active);
            elements.body.classList.add(CONFIG.CLASSES.filterOpen);
            elements.filterSidebar.setAttribute('aria-hidden', 'false');
            if (elements.filterToggle) {
                elements.filterToggle.setAttribute('aria-expanded', 'true');
            }
            if (isMobile()) {
                lockScroll();
            }
            // Focus first interactive element
            const firstInput = elements.filterSidebar.querySelector('input, button, select');
            if (firstInput) firstInput.focus();
        },

        close() {
            if (!elements.filterSidebar) return;
            elements.filterSidebar.classList.remove(CONFIG.CLASSES.active);
            elements.body.classList.remove(CONFIG.CLASSES.filterOpen);
            elements.filterSidebar.setAttribute('aria-hidden', 'true');
            if (elements.filterToggle) {
                elements.filterToggle.setAttribute('aria-expanded', 'false');
                elements.filterToggle.focus();
            }
            if (isMobile()) {
                unlockScroll();
            }
        },

        toggle() {
            if (elements.filterSidebar?.classList.contains(CONFIG.CLASSES.active)) {
                this.close();
            } else {
                this.open();
            }
        },
    };

    // Product Filtering
    const productFilter = {
        init() {
            if (!elements.productGrid) return;

            // Gather all products with their data
            const items = elements.productGrid.querySelectorAll(CONFIG.SELECTORS.productItem);
            state.allProducts = Array.from(items).map((item, index) => ({
                element: item,
                index: index,
                category: item.dataset.category || '',
                price: parseFloat(String(item.dataset.price).replace(/[^0-9.-]+/g,"")) || 0,
                name: item.querySelector('.cs-h3')?.textContent || '',
                inStock: item.dataset.inStock !== 'false', // Default to true if not specified
                onSale: item.dataset.onSale === 'true',
            }));

            state.filteredProducts = [...state.allProducts];
            this.applyFilters();
        },

        applyFilters() {
            // First filter
            state.filteredProducts = state.allProducts.filter(product => {
                // Category filter
                if (state.selectedCategories.length > 0) {
                    if (!state.selectedCategories.includes(product.category)) {
                        return false;
                    }
                }

                // Price range filter
                if (state.selectedPriceRange) {
                    const [min, max] = state.selectedPriceRange;
                    if (max === null) {
                        // "Over X" range
                        if (product.price < min) return false;
                    } else if (min === null) {
                        // "Under X" range
                        if (product.price > max) return false;
                    } else {
                        if (product.price < min || product.price > max) return false;
                    }
                }

                // In Stock filter
                if (state.inStockOnly && !product.inStock) {
                    return false;
                }

                // On Sale filter
                if (state.onSaleOnly && !product.onSale) {
                    return false;
                }

                return true;
            });

            // Then sort
            this.sortProducts();

            // Reset to page 1 when filters change
            state.currentPage = 1;
            this.updateDisplay();
        },

        sortProducts() {
            switch (state.sortBy) {
                case 'price-low':
                    state.filteredProducts.sort((a, b) => a.price - b.price);
                    break;
                case 'price-high':
                    state.filteredProducts.sort((a, b) => b.price - a.price);
                    break;
                case 'name-az':
                    state.filteredProducts.sort((a, b) => a.name.localeCompare(b.name));
                    break;
                case 'name-za':
                    state.filteredProducts.sort((a, b) => b.name.localeCompare(a.name));
                    break;
                case 'oldest':
                    state.filteredProducts.sort((a, b) => a.index - b.index);
                    break;
                case 'newest':
                default:
                    state.filteredProducts.sort((a, b) => b.index - a.index);
                    break;
            }
        },

        updateDisplay() {
            const totalProducts = state.filteredProducts.length;
            const totalPages = Math.ceil(totalProducts / CONFIG.ITEMS_PER_PAGE);
            const startIndex = (state.currentPage - 1) * CONFIG.ITEMS_PER_PAGE;
            const endIndex = startIndex + CONFIG.ITEMS_PER_PAGE;

            // Hide all products first
            state.allProducts.forEach(product => {
                product.element.classList.add(CONFIG.CLASSES.hidden);
            });

            // Get products for current page (already sorted by sortProducts)
            const pageProducts = state.filteredProducts.slice(startIndex, endIndex);

            // Reorder DOM elements and show them
            pageProducts.forEach((product, i) => {
                product.element.classList.remove(CONFIG.CLASSES.hidden);
                // Use CSS order property to visually reorder
                product.element.style.order = i;
            });

            // Reset order on hidden items so they don't interfere
            state.allProducts.forEach(product => {
                if (product.element.classList.contains(CONFIG.CLASSES.hidden)) {
                    product.element.style.order = 9999;
                }
            });

            // Update results count
            if (elements.resultsCount) {
                const showing = Math.min(endIndex, totalProducts) - startIndex;
                elements.resultsCount.textContent = `Showing ${showing > 0 ? startIndex + 1 : 0}-${Math.min(endIndex, totalProducts)} of ${totalProducts} products`;
            }

            // Update active filters count
            if (elements.activeFiltersCount) {
                let count = state.selectedCategories.length;
                if (state.selectedPriceRange) count++;
                if (state.inStockOnly) count++;
                if (state.onSaleOnly) count++;
                elements.activeFiltersCount.textContent = count > 0 ? `(${count})` : '';
            }

            // Update pagination
            paginationManager.render(totalPages);
        },

        clearAll() {
            state.selectedCategories = [];
            state.selectedPriceRange = null;
            state.sortBy = 'newest';
            state.inStockOnly = false;
            state.onSaleOnly = false;
            state.currentPage = 1;

            // Reset checkboxes
            document.querySelectorAll(CONFIG.SELECTORS.categoryCheckbox).forEach(cb => {
                cb.checked = false;
            });

            // Reset radio buttons
            document.querySelectorAll(CONFIG.SELECTORS.priceRadio).forEach(radio => {
                radio.checked = false;
            });

            // Check the "All Prices" option if it exists
            const allPricesRadio = document.querySelector('.cs-price-radio[value="all"]');
            if (allPricesRadio) allPricesRadio.checked = true;

            // Reset sort select
            if (elements.sortSelect) {
                elements.sortSelect.value = 'newest';
            }

            // Reset toggles
            if (elements.inStockToggle) {
                elements.inStockToggle.checked = false;
            }
            if (elements.onSaleToggle) {
                elements.onSaleToggle.checked = false;
            }

            this.applyFilters();
        },
    };

    // Pagination Management
    const paginationManager = {
        // Get max visible pages based on viewport
        getMaxVisiblePages() {
            // On mobile, show fewer page buttons for better touch targets
            if (window.innerWidth < 480) {
                return 3; // Very small screens: just first, current, last
            } else if (window.innerWidth < 768) {
                return 5; // Mobile: show 5 buttons max
            }
            return 7; // Desktop: show 7 buttons max
        },

        render(totalPages) {
            if (!elements.pagination) return;

            const pagesContainer = elements.pagination.querySelector('.cs-pages');
            const pageStatus = elements.pagination.querySelector('#cs-page-status');
            const pageSelect = elements.pagination.querySelector('#cs-page-select');
            
            if (!pagesContainer) return;

            // Clear existing page buttons
            pagesContainer.innerHTML = '';

            // Update page status text (always visible for accessibility)
            if (pageStatus) {
                if (totalPages <= 1) {
                    pageStatus.textContent = `${state.filteredProducts.length} products`;
                } else {
                    pageStatus.textContent = `Page ${state.currentPage} of ${totalPages}`;
                }
            }

            // Update page jump select
            if (pageSelect) {
                this.updatePageSelect(pageSelect, totalPages);
            }

            if (totalPages <= 1) {
                elements.pagination.classList.add(CONFIG.CLASSES.hidden);
                return;
            }

            elements.pagination.classList.remove(CONFIG.CLASSES.hidden);

            // Determine which pages to show based on viewport
            const pagesToShow = this.getVisiblePages(totalPages);

            pagesToShow.forEach((page, index) => {
                if (page === '...') {
                    const ellipsis = document.createElement('span');
                    ellipsis.className = 'cs-ellipsis';
                    ellipsis.textContent = '…';
                    ellipsis.setAttribute('aria-hidden', 'true');
                    pagesContainer.appendChild(ellipsis);
                } else {
                    const btn = document.createElement('button');
                    btn.className = 'cs-page-btn';
                    btn.textContent = page;
                    btn.type = 'button';
                    btn.setAttribute('aria-label', `Page ${page}${page === state.currentPage ? ', current page' : ''}`);
                    if (page === state.currentPage) {
                        btn.classList.add(CONFIG.CLASSES.active);
                        btn.setAttribute('aria-current', 'page');
                    }
                    btn.addEventListener('click', () => this.goToPage(page));
                    pagesContainer.appendChild(btn);
                }
            });

            // Update prev/next buttons
            this.updateNavButtons(totalPages);
        },

        updatePageSelect(selectElement, totalPages) {
            // Clear and rebuild options
            selectElement.innerHTML = '';
            
            for (let i = 1; i <= totalPages; i++) {
                const option = document.createElement('option');
                option.value = i;
                option.textContent = i;
                if (i === state.currentPage) {
                    option.selected = true;
                }
                selectElement.appendChild(option);
            }

            // Show/hide page jump based on total pages
            const pageJumpContainer = elements.pagination.querySelector('.cs-page-jump');
            if (pageJumpContainer) {
                // Show page jump when there are more than 5 pages
                if (totalPages > 5) {
                    pageJumpContainer.classList.remove(CONFIG.CLASSES.hidden);
                } else {
                    pageJumpContainer.classList.add(CONFIG.CLASSES.hidden);
                }
            }
        },

        updateNavButtons(totalPages) {
            if (elements.prevButton) {
                const isDisabled = state.currentPage === 1;
                elements.prevButton.disabled = isDisabled;
                elements.prevButton.classList.toggle(CONFIG.CLASSES.disabled, isDisabled);
                elements.prevButton.setAttribute('aria-disabled', isDisabled.toString());
            }
            if (elements.nextButton) {
                const isDisabled = state.currentPage === totalPages;
                elements.nextButton.disabled = isDisabled;
                elements.nextButton.classList.toggle(CONFIG.CLASSES.disabled, isDisabled);
                elements.nextButton.setAttribute('aria-disabled', isDisabled.toString());
            }
        },

        getVisiblePages(totalPages) {
            const current = state.currentPage;
            const pages = [];
            const maxVisible = this.getMaxVisiblePages();

            if (totalPages <= maxVisible) {
                // Show all pages
                for (let i = 1; i <= totalPages; i++) {
                    pages.push(i);
                }
            } else if (maxVisible === 3) {
                // Very compact mode for tiny screens
                pages.push(1);
                if (current !== 1 && current !== totalPages) {
                    pages.push('...');
                    pages.push(current);
                }
                if (current !== totalPages) {
                    if (current !== 1 && current < totalPages - 1) {
                        pages.push('...');
                    }
                    pages.push(totalPages);
                }
            } else {
                // Standard smart pagination
                pages.push(1);

                if (current > 3) {
                    pages.push('...');
                }

                // Calculate range around current page
                const rangeSize = maxVisible === 5 ? 1 : 1;
                const start = Math.max(2, current - rangeSize);
                const end = Math.min(totalPages - 1, current + rangeSize);

                for (let i = start; i <= end; i++) {
                    pages.push(i);
                }

                if (current < totalPages - 2) {
                    pages.push('...');
                }

                pages.push(totalPages);
            }

            // Remove duplicate values while preserving order
            const seen = new Set();
            return pages.filter(page => {
                if (page === '...') return true;
                if (seen.has(page)) return false;
                seen.add(page);
                return true;
            });
        },

        goToPage(page) {
            const totalPages = Math.ceil(state.filteredProducts.length / CONFIG.ITEMS_PER_PAGE);
            if (page < 1 || page > totalPages) return;

            state.currentPage = page;
            productFilter.updateDisplay();

            // Scroll to top of products section with header offset
            const productsSection = document.querySelector('#products-1394');
            if (productsSection) {
                // Get the header height to offset scroll position
                const header = document.querySelector('#cs-navigation');
                const headerHeight = header ? header.offsetHeight : 0;
                const offset = headerHeight + 20; // Add some extra padding
                
                const elementPosition = productsSection.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - offset;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }

            // Announce page change for screen readers
            this.announcePageChange(page, totalPages);
        },

        announcePageChange(page, totalPages) {
            // The aria-live region will automatically announce changes
            const pageStatus = document.querySelector('#cs-page-status');
            if (pageStatus) {
                // Force re-announcement by briefly clearing and setting
                const text = `Page ${page} of ${totalPages}`;
                pageStatus.textContent = text;
            }
        },

        nextPage() {
            const totalPages = Math.ceil(state.filteredProducts.length / CONFIG.ITEMS_PER_PAGE);
            if (state.currentPage < totalPages) {
                this.goToPage(state.currentPage + 1);
            }
        },

        prevPage() {
            if (state.currentPage > 1) {
                this.goToPage(state.currentPage - 1);
            }
        },

        handlePageSelectChange(e) {
            const page = parseInt(e.target.value, 10);
            if (!isNaN(page)) {
                paginationManager.goToPage(page);
            }
        },
    };

    // Event Handlers
    const eventHandlers = {
        handleCategoryChange(e) {
            const checkbox = e.target;
            const category = checkbox.value;

            if (checkbox.checked) {
                if (!state.selectedCategories.includes(category)) {
                    state.selectedCategories.push(category);
                }
            } else {
                state.selectedCategories = state.selectedCategories.filter(c => c !== category);
            }

            productFilter.applyFilters();
        },

        handlePriceChange(e) {
            const radio = e.target;
            const value = radio.value;

            if (value === 'all') {
                state.selectedPriceRange = null;
            } else {
                const [min, max] = value.split('-').map(v => v === 'null' ? null : parseFloat(v));
                state.selectedPriceRange = [min, max];
            }

            productFilter.applyFilters();
        },

        handleSortChange(e) {
            state.sortBy = e.target.value;
            productFilter.applyFilters();
        },

        handleInStockChange(e) {
            state.inStockOnly = e.target.checked;
            productFilter.applyFilters();
        },

        handleOnSaleChange(e) {
            state.onSaleOnly = e.target.checked;
            productFilter.applyFilters();
        },

        handleKeydown(e) {
            if (e.key === 'Escape' && elements.filterSidebar?.classList.contains(CONFIG.CLASSES.active)) {
                filterManager.close();
            }
        },

        handleBackdropClick(e) {
            if (e.target === elements.filterSidebar) {
                filterManager.close();
            }
        },

        handleResize() {
            // On desktop, ensure filter is always visible and no scroll lock
            if (!isMobile()) {
                unlockScroll();
                elements.body?.classList.remove(CONFIG.CLASSES.filterOpen);
                elements.filterSidebar?.setAttribute('aria-hidden', 'false');
            } else {
                // On mobile, if NOT active, ensure aria-hidden is true
                if (!elements.filterSidebar?.classList.contains(CONFIG.CLASSES.active)) {
                    elements.filterSidebar?.setAttribute('aria-hidden', 'true');
                }
            }
        },
    };

    // Initialization
    function init() {
        if (!elements.productGrid) return;

        // Initialize aria-hidden state based on viewport
        if (elements.filterSidebar) {
            elements.filterSidebar.setAttribute('aria-hidden', isMobile() ? 'true' : 'false');
        }

        // Initialize products
        productFilter.init();

        // Filter toggle button
        if (elements.filterToggle) {
            elements.filterToggle.addEventListener('click', () => filterManager.toggle());
        }

        // Filter close button
        if (elements.filterClose) {
            elements.filterClose.addEventListener('click', () => filterManager.close());
        }

        // Backdrop click to close
        if (elements.filterSidebar) {
            elements.filterSidebar.addEventListener('click', eventHandlers.handleBackdropClick);
        }

        // Category checkboxes
        document.querySelectorAll(CONFIG.SELECTORS.categoryCheckbox).forEach(checkbox => {
            checkbox.addEventListener('change', eventHandlers.handleCategoryChange);
        });

        // Price radio buttons
        document.querySelectorAll(CONFIG.SELECTORS.priceRadio).forEach(radio => {
            radio.addEventListener('change', eventHandlers.handlePriceChange);
        });

        // Sort select
        if (elements.sortSelect) {
            elements.sortSelect.addEventListener('change', eventHandlers.handleSortChange);
        }

        // In Stock toggle
        if (elements.inStockToggle) {
            elements.inStockToggle.addEventListener('change', eventHandlers.handleInStockChange);
        }

        // On Sale toggle
        if (elements.onSaleToggle) {
            elements.onSaleToggle.addEventListener('change', eventHandlers.handleOnSaleChange);
        }

        // Clear filters button
        if (elements.clearFilters) {
            elements.clearFilters.addEventListener('click', () => productFilter.clearAll());
        }

        // Pagination prev/next
        if (elements.prevButton) {
            elements.prevButton.addEventListener('click', () => paginationManager.prevPage());
        }
        if (elements.nextButton) {
            elements.nextButton.addEventListener('click', () => paginationManager.nextPage());
        }

        // Page jump select
        const pageSelect = document.querySelector('#cs-page-select');
        if (pageSelect) {
            pageSelect.addEventListener('change', paginationManager.handlePageSelectChange);
        }

        // Keyboard events
        document.addEventListener('keydown', eventHandlers.handleKeydown);

        // Resize handler - also re-render pagination for responsive behavior
        let resizeTimeout;
        window.addEventListener('resize', () => {
            eventHandlers.handleResize();
            // Debounce pagination re-render
            clearTimeout(resizeTimeout);
            resizeTimeout = setTimeout(() => {
                const totalPages = Math.ceil(state.filteredProducts.length / CONFIG.ITEMS_PER_PAGE);
                paginationManager.render(totalPages);
            }, 150);
        });
    }

    // Run on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
