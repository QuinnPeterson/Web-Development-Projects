document.addEventListener('DOMContentLoaded', function() {
    // Quantity counter functionality
    const quantityInput = document.getElementById('quantity');
    const minusBtn = document.querySelector('.cs-minus');
    const plusBtn = document.querySelector('.cs-plus');
    const addToCartBtn = document.getElementById('add-to-cart-btn');

    if (quantityInput && minusBtn && plusBtn && addToCartBtn) {
        function updateQuantity(newValue) {
            const min = parseInt(quantityInput.min) || 1;
            const max = parseInt(quantityInput.max) || 99;
            const value = Math.max(min, Math.min(max, parseInt(newValue) || min));
            
            quantityInput.value = value;
            addToCartBtn.setAttribute('data-item-quantity', value);
            
            // Update button states
            minusBtn.disabled = value <= min;
            plusBtn.disabled = value >= max;
            
            return value;
        }

        // Minus button
        minusBtn.addEventListener('click', function() {
            updateQuantity(parseInt(quantityInput.value) - 1);
        });

        // Plus button
        plusBtn.addEventListener('click', function() {
            updateQuantity(parseInt(quantityInput.value) + 1);
        });

        // Input change
        quantityInput.addEventListener('input', function() {
            updateQuantity(this.value);
        });

        // Input blur (when user leaves the field)
        quantityInput.addEventListener('blur', function() {
            if (!this.value || parseInt(this.value) < 1) {
                updateQuantity(1);
            }
        });

        // Initialize
        updateQuantity(quantityInput.value);
    }

    // Snipcart functionality
    const button = document.getElementById('add-to-cart-btn');
    const selects = document.querySelectorAll('.cs-option-select');
    const optionsContainer = document.querySelector('.cs-options');
    const priceDisplay = document.querySelector('.cs-price');
    
    if (button && selects.length > 0) {
        // Check if product is out of stock - if so, validation shouldn't run or enable the button
        const isOutOfStock = button.disabled && button.textContent.trim() === 'Out of Stock';
        const originalText = button.textContent;
        
        // Get base price from the options container or from the button's data attribute
        const basePrice = optionsContainer 
            ? parseFloat(optionsContainer.getAttribute('data-base-price')) || 0
            : parseFloat(button.getAttribute('data-item-price')) || 0;

        function updateCustomValue(select) {
            const index = select.getAttribute('data-option-index');
            const name = select.getAttribute('data-option-name');
            if (select.value) {
                button.setAttribute('data-item-custom' + index + '-value', select.value);
            } else {
                button.removeAttribute('data-item-custom' + index + '-value');
            }
        }

        function calculateTotalPrice() {
            let totalPrice = basePrice;
            
            selects.forEach(select => {
                const selectedOption = select.options[select.selectedIndex];
                if (selectedOption) {
                    const priceModifier = parseFloat(selectedOption.getAttribute('data-price')) || 0;
                    totalPrice += priceModifier;
                }
            });
            
            return totalPrice;
        }

        function updatePriceDisplay() {
            const totalPrice = calculateTotalPrice();
            
            // Update the displayed price
            if (priceDisplay) {
                priceDisplay.textContent = '$' + totalPrice.toFixed(2);
            }
            
            // NOTE: We don't update button data-item-price here because 
            // we're using Snipcart's native [+modifier] syntax in the options string
        }

        function checkValidity() {
            // If out of stock, do not enable button or change text
            if (isOutOfStock) return;

            let allValid = true;
            selects.forEach(select => {
                if (select.required && !select.value) {
                    allValid = false;
                }
            });
            
            if (allValid) {
                button.disabled = false;
                button.textContent = originalText;
            } else {
                button.disabled = true;
                button.textContent = 'Select Options';
            }
        }

        selects.forEach(function(select) {
            updateCustomValue(select);
            select.addEventListener('change', function() {
                updateCustomValue(this);
                updatePriceDisplay();
                checkValidity();
            });
        });
        
        button.addEventListener('click', function() {
            selects.forEach(function(select) {
                updateCustomValue(select);
            });
        });

        // Initial check and price update
        updatePriceDisplay();
        checkValidity();
    }

    // Image Gallery Modal functionality
    const modal = document.getElementById('imageModal');
    const modalImage = document.getElementById('modalImage');
    const modalClose = modal.querySelector('.cs-modal-close');
    const modalPrev = modal.querySelector('.cs-prev');
    const modalNext = modal.querySelector('.cs-next');
    const currentImageSpan = document.getElementById('currentImage');
    const totalImagesSpan = document.getElementById('totalImages');
    const thumbnailsContainer = document.getElementById('modalThumbnails');
    const imageWrapper = modal.querySelector('.cs-modal-image-wrapper');

    // Collect all product images
    const productImages = [];
    const mainImage = document.querySelector('.cs-main-image img');
    if (mainImage) {
        productImages.push({
            src: mainImage.src,
            alt: mainImage.alt
        });
    }

    const galleryImages = document.querySelectorAll('.cs-gallery .cs-picture img');
    galleryImages.forEach(img => {
        productImages.push({
            src: img.src,
            alt: img.alt
        });
    });

    let currentIndex = 0;

    // Only initialize modal if there are images
    if (productImages.length > 0) {
        totalImagesSpan.textContent = productImages.length;

        // Create thumbnails
        productImages.forEach((img, index) => {
            const thumb = document.createElement('div');
            thumb.className = 'cs-modal-thumb';
            if (index === 0) thumb.classList.add('cs-active');
            thumb.innerHTML = `<img src="${img.src}" alt="${img.alt}" />`;
            thumb.addEventListener('click', () => showImage(index));
            thumbnailsContainer.appendChild(thumb);
        });

        function showImage(index) {
            currentIndex = index;
            modalImage.src = productImages[index].src;
            modalImage.alt = productImages[index].alt;
            currentImageSpan.textContent = index + 1;

            // Update thumbnails
            const thumbs = thumbnailsContainer.querySelectorAll('.cs-modal-thumb');
            thumbs.forEach((thumb, i) => {
                thumb.classList.toggle('cs-active', i === index);
            });

            // Update navigation buttons
            modalPrev.classList.toggle('cs-disabled', index === 0);
            modalNext.classList.toggle('cs-disabled', index === productImages.length - 1);

            // Scroll active thumbnail into view
            if (thumbs[index]) {
                thumbs[index].scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
            }
        }

        let scrollPosition = 0;

        function lockScroll() {
            scrollPosition = window.pageYOffset;

            document.documentElement.style.overflow = 'hidden';
            document.body.style.overflow = 'hidden';

            // Prevent iOS scroll jump
            document.body.style.position = 'fixed';
            document.body.style.top = `-${scrollPosition}px`;
            document.body.style.width = '100%';
        }

        function unlockScroll() {
            document.documentElement.style.overflow = '';
            document.body.style.overflow = '';
            document.body.style.position = '';
            document.body.style.top = '';
            document.body.style.width = '';

            window.scrollTo(0, scrollPosition);
        }

        function openModal(index = 0) {
            modal.classList.add('cs-active');
            modal.setAttribute('aria-hidden', 'false');
            lockScroll();
            showImage(index);
        }

        function closeModal() {
            modal.classList.remove('cs-active');
            modal.setAttribute('aria-hidden', 'true');
            unlockScroll();
        }

        function nextImage() {
            if (currentIndex < productImages.length - 1) {
                showImage(currentIndex + 1);
            }
        }

        function prevImage() {
            if (currentIndex > 0) {
                showImage(currentIndex - 1);
            }
        }

        // Event listeners
        const allClickableImages = document.querySelectorAll('.cs-picture');
        allClickableImages.forEach((picture, index) => {
            picture.style.cursor = 'pointer';
            picture.addEventListener('click', () => {
                const imageIndex = parseInt(picture.getAttribute('data-image-index')) || 0;
                openModal(imageIndex);
            });
        });

        modalClose.addEventListener('click', closeModal);
        modalPrev.addEventListener('click', prevImage);
        modalNext.addEventListener('click', nextImage);

        // Close on backdrop click
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModal();
            }
        });

        // Keyboard navigation
        document.addEventListener('keydown', function(e) {
            if (!modal.classList.contains('cs-active')) return;

            if (e.key === 'Escape') {
                closeModal();
            } else if (e.key === 'ArrowRight') {
                nextImage();
            } else if (e.key === 'ArrowLeft') {
                prevImage();
            }
        });

        // Touch swipe functionality
        let touchStartX = 0;
        let touchEndX = 0;
        let touchStartY = 0;
        let touchEndY = 0;
        const swipeThreshold = 50;
        const verticalThreshold = 30;

        imageWrapper.addEventListener('touchstart', function(e) {
            touchStartX = e.changedTouches[0].screenX;
            touchStartY = e.changedTouches[0].screenY;
        }, { passive: true });

        imageWrapper.addEventListener('touchend', function(e) {
            touchEndX = e.changedTouches[0].screenX;
            touchEndY = e.changedTouches[0].screenY;
            handleSwipe();
        }, { passive: true });

        function handleSwipe() {
            const horizontalDiff = touchStartX - touchEndX;
            const verticalDiff = Math.abs(touchStartY - touchEndY);
            
            if (verticalDiff > verticalThreshold) {
                return;
            }

            if (Math.abs(horizontalDiff) > swipeThreshold) {
                if (horizontalDiff > 0) {
                    nextImage();
                } else {
                    prevImage();
                }
            }
        }
    }
});