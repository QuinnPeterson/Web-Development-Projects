/**
 * Generate Test Products Script
 * Creates a specified number of test product markdown files for pagination testing
 * 
 * Usage: node scripts/generate-test-products.js [count]
 * Example: node scripts/generate-test-products.js 100
 */

const fs = require('fs');
const path = require('path');

// Configuration
const PRODUCTS_DIR = path.join(__dirname, '..', 'src', 'content', 'products');
const DEFAULT_COUNT = 100;

// Categories from productCategories.json
const CATEGORIES = ['Electronics', 'Accessories', 'Clothing', 'Home & Garden', 'Sports & Outdoors'];

// Sample product names by category
const PRODUCT_NAMES = {
    'Electronics': ['Wireless Headphones', 'Bluetooth Speaker', 'Smart Watch', 'Tablet Stand', 'USB-C Hub', 'Portable Charger', 'LED Monitor', 'Mechanical Keyboard', 'Gaming Mouse', 'Webcam HD'],
    'Accessories': ['Phone Case', 'Laptop Sleeve', 'Cable Organizer', 'Screen Protector', 'Wireless Earbuds Case', 'Watch Band', 'Ring Holder', 'Card Wallet', 'Keychain Charger', 'Travel Adapter'],
    'Clothing': ['Cotton T-Shirt', 'Hoodie', 'Running Shorts', 'Yoga Pants', 'Winter Jacket', 'Baseball Cap', 'Athletic Socks', 'Casual Sneakers', 'Denim Jeans', 'Polo Shirt'],
    'Home & Garden': ['Plant Pot', 'LED Lamp', 'Throw Pillow', 'Wall Clock', 'Picture Frame', 'Candle Set', 'Door Mat', 'Garden Tools', 'Bird Feeder', 'Wind Chimes'],
    'Sports & Outdoors': ['Yoga Mat', 'Resistance Bands', 'Water Bottle', 'Camping Tent', 'Hiking Backpack', 'Fitness Tracker', 'Jump Rope', 'Foam Roller', 'Cycling Gloves', 'Running Belt']
};

// Sample descriptions
const DESCRIPTIONS = [
    'High-quality product designed for everyday use. Features premium materials and excellent craftsmanship.',
    'Perfect for those who demand the best. This product combines style with functionality.',
    'An essential addition to your collection. Made with attention to detail and built to last.',
    'Experience superior quality with this carefully crafted item. Ideal for home or office use.',
    'Designed with you in mind. This product offers exceptional value and performance.',
    'Premium quality meets affordable pricing. A must-have for any discerning customer.',
    'Crafted from sustainable materials. Eco-friendly without compromising on quality.',
    'The perfect gift for any occasion. Elegant design with practical functionality.',
    'Professional grade quality for demanding users. Exceeds industry standards.',
    'Innovative design that sets new standards. Be the first to experience the difference.'
];

// Colors for variety
const COLORS = ['Black', 'White', 'Navy', 'Gray', 'Red', 'Blue', 'Green', 'Orange', 'Purple', 'Teal'];

// Generate a random price between min and max
function randomPrice(min, max) {
    return (Math.random() * (max - min) + min).toFixed(2);
}

// Get a random item from an array
function randomFrom(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

// Generate SKU
function generateSKU(index) {
    return `TEST-${String(index).padStart(4, '0')}`;
}

// Generate a product markdown file content
function generateProductContent(index) {
    const category = randomFrom(CATEGORIES);
    const baseName = randomFrom(PRODUCT_NAMES[category]);
    const color = randomFrom(COLORS);
    const productName = `${color} ${baseName} ${index}`;
    const description = randomFrom(DESCRIPTIONS);
    const price = randomPrice(19.99, 299.99);
    
    // 20% chance of being on sale
    const isOnSale = Math.random() < 0.2;
    const salePrice = isOnSale ? (parseFloat(price) * 0.8).toFixed(2) : '';
    
    // 10% chance of being out of stock
    const inStock = Math.random() > 0.1;
    
    // 15% chance of being a digital good
    const isDigital = Math.random() < 0.15;
    // Generate a sample GUID for digital products (in real usage, this comes from Snipcart dashboard)
    const fileGuid = isDigital ? `${Math.random().toString(36).substring(2, 10)}-${Math.random().toString(36).substring(2, 6)}-${Math.random().toString(36).substring(2, 6)}-${Math.random().toString(36).substring(2, 6)}-${Math.random().toString(36).substring(2, 14)}` : '';
    
    // Random status
    const statuses = ['New', 'Popular', 'Limited', 'Bestseller', ''];
    const status = isOnSale ? '' : randomFrom(statuses); // Sale overrides status

    const content = `---
title: "${productName}"
description: "${description}"
category: "${category}"
price: "${price}"
${salePrice ? `salePrice: "${salePrice}"` : '# No sale price'}
sku: "${generateSKU(index)}"
status: "${status}"
inStock: ${inStock}
${isDigital ? `digitalGood: true
fileGuid: "${fileGuid}"` : '# Not a digital product'}
image: "/assets/images/products/placeholder.jpg"
imageAlt: "${productName}"
---

## About This Product

${description}

### Features
- Premium quality materials
- Designed for durability
- Easy to use
- Great value for money
${isDigital ? '- Instant digital download after purchase' : ''}

### Specifications
- Category: ${category}
- Color: ${color}
- SKU: ${generateSKU(index)}
${isDigital ? '- Type: Digital Download' : ''}
`;

    return content;
}

// Generate filename-safe slug
function slugify(text) {
    return text
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
}

// Main function
function generateProducts(count) {
    console.log(`\n📦 Generating ${count} test products...\n`);

    // Ensure products directory exists
    if (!fs.existsSync(PRODUCTS_DIR)) {
        fs.mkdirSync(PRODUCTS_DIR, { recursive: true });
    }

    let created = 0;
    let skipped = 0;

    for (let i = 1; i <= count; i++) {
        const category = randomFrom(CATEGORIES);
        const baseName = randomFrom(PRODUCT_NAMES[category]);
        const color = randomFrom(COLORS);
        const productName = `${color} ${baseName} ${i}`;
        const filename = `test-product-${String(i).padStart(3, '0')}.md`;
        const filepath = path.join(PRODUCTS_DIR, filename);

        // Check if file already exists
        if (fs.existsSync(filepath)) {
            skipped++;
            continue;
        }

        const content = generateProductContent(i);
        fs.writeFileSync(filepath, content);
        created++;

        // Progress indicator
        if (i % 25 === 0 || i === count) {
            const percent = Math.round((i / count) * 100);
            process.stdout.write(`\r  Progress: ${i}/${count} (${percent}%)`);
        }
    }

    console.log('\n');
    console.log(`✅ Created: ${created} products`);
    if (skipped > 0) {
        console.log(`⏭️  Skipped: ${skipped} (already exist)`);
    }
    console.log(`\n📁 Products saved to: ${PRODUCTS_DIR}`);
    console.log('\n💡 Run "npm run build" or restart "npm start" to see the changes.\n');
}

// Delete test products (cleanup function)
function deleteTestProducts() {
    console.log('\n🗑️  Deleting test products...\n');

    const files = fs.readdirSync(PRODUCTS_DIR);
    let deleted = 0;

    files.forEach(file => {
        if (file.startsWith('test-product-') && file.endsWith('.md')) {
            fs.unlinkSync(path.join(PRODUCTS_DIR, file));
            deleted++;
        }
    });

    console.log(`✅ Deleted: ${deleted} test products\n`);
}

// Parse command line arguments
const args = process.argv.slice(2);

if (args[0] === '--delete' || args[0] === '-d') {
    deleteTestProducts();
} else {
    const count = parseInt(args[0]) || DEFAULT_COUNT;
    if (count < 1 || count > 1000) {
        console.error('❌ Please specify a count between 1 and 1000');
        process.exit(1);
    }
    generateProducts(count);
}
