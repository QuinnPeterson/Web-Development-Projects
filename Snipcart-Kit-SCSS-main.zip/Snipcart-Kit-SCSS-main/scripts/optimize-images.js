const fs = require('fs');
const path = require('path');

// Try to load sharp
let sharp;
try {
    sharp = require('sharp');
} catch (e) {
    try {
        // Try to find it in nested node_modules if not hoisted
        const possiblePaths = [
            path.join(process.cwd(), 'node_modules', 'sharp'),
            path.join(process.cwd(), 'node_modules', '@codestitchofficial', 'eleventy-plugin-sharp-images', 'node_modules', 'sharp')
        ];
        for (const p of possiblePaths) {
            if (fs.existsSync(p)) {
                sharp = require(p);
                break;
            }
        }
        if (!sharp) throw e;
    } catch (e2) {
        console.error("Error: Could not load 'sharp' module. It seems it is not installed or not found.");
        console.error("Please run: npm install sharp --save-dev");
        process.exit(1);
    }
}

// Configuration
// Allow command line argument to override default path.
// Usage: node optimize-images.js "./path/to/images"
const args = process.argv.slice(2);
const defaultPath = path.join(__dirname, '../src/assets/images');
const TARGET_DIR = args[0] ? path.resolve(process.cwd(), args[0]) : defaultPath;

const MAX_WIDTH = 2000;
const FILE_SIZE_THRESHOLD = 500 * 1024; // 500KB - Optimize anything larger than this

async function processDirectory(directory) {
    if (!fs.existsSync(directory)) {
        console.log(`Directory not found: ${directory}`);
        return;
    }

    const files = fs.readdirSync(directory);

    for (const file of files) {
        const fullPath = path.join(directory, file);
        const stat = fs.statSync(fullPath);

        if (stat.isDirectory()) {
            await processDirectory(fullPath);
        } else if (stat.isFile()) {
            const ext = path.extname(file).toLowerCase();
            if (['.jpg', '.jpeg', '.png', '.webp'].includes(ext)) {
                if (stat.size > FILE_SIZE_THRESHOLD) {
                    await optimizeImage(fullPath);
                }
            }
        }
    }
}

async function optimizeImage(filePath) {
    const fileName = path.basename(filePath);
    
    const sizeMB = (fs.statSync(filePath).size / 1024 / 1024).toFixed(2);
    console.log(`Optimizing: ${fileName} (${sizeMB} MB)`);
    
    try {
        const originalBuffer = fs.readFileSync(filePath);
        let transformer = sharp(originalBuffer).rotate();
        const metadata = await transformer.metadata();

        let didResize = false;
        if (metadata.width > MAX_WIDTH) {
            console.log(`  Resizing from ${metadata.width}px to ${MAX_WIDTH}px`);
            transformer = transformer.resize({ width: MAX_WIDTH, withoutEnlargement: true });
            didResize = true;
        }

        // Apply compression
        if (metadata.format === 'jpeg' || metadata.format === 'jpg') {
            transformer = transformer.jpeg({ quality: 80, mozjpeg: true });
        } else if (metadata.format === 'png') {
            transformer = transformer.png({ quality: 80, compressionLevel: 9 });
        } else if (metadata.format === 'webp') {
            transformer = transformer.webp({ quality: 80 });
        }

        const outputBuffer = await transformer.toBuffer();
        
        // Calculate savings
        const newSize = outputBuffer.length;
        const oldSize = originalBuffer.length;
        
        if (newSize < oldSize) {
            fs.writeFileSync(filePath, outputBuffer);
            const saved = ((oldSize - newSize) / 1024 / 1024).toFixed(2);
            console.log(`  Saved ${saved} MB! New size: ${(newSize / 1024 / 1024).toFixed(2)} MB`);
        } else {
           console.log(`  No savings achieved (already optimized?), skipping overwrite.`);
        }
        
    } catch (error) {
        console.error(`  Error utilizing ${filePath}:`, error.message);
    }
}

console.log('Starting image optimization...');
processDirectory(TARGET_DIR)
    .then(() => console.log('Optimization complete!'))
    .catch(err => console.error('Fatal error:', err));